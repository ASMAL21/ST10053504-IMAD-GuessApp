package com.example.test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val randomValues = List(1) { Random.nextInt(0, 100) }
        var DisplayValue = findViewById<TextView>(R.id.DisplayAnswer)
        var Button = findViewById<Button>(R.id.button)
        var Restart = findViewById<Button>(R.id.Restart)
        var inputValue = findViewById<TextInputEditText>(R.id.input)

        Button.setOnClickListener {
            if(inputValue.text == randomValues) {
                DisplayValue.text = "Correct"
            } else {
                DisplayValue.text = "Incorrect :" + randomValues.toString()
            }
        }
        Restart.setOnClickListener {
            val randomValues = List(1) { Random.nextInt(0, 100) }
        }
    }
}